<aside class="left-off-canvas-menu" aria-hidden="true">
    <?php foundationPress_mobile_off_canvas(); ?>
</aside>